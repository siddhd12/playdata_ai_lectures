from django.shortcuts import render,redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.forms import UserCreationForm
from django.contrib import auth
from django.http import HttpResponse, HttpResponseRedirect
from django.urls import reverse

def index_page(request):
    context = {}
    return render(request,"main/index.html",context)

# Create your views here.


