from django.shortcuts import render,redirect
# import os, sys
# main_dir = os.path.dirname(os.path.realpath(__file__))
# print(main_dir)
# cus = os.path.join(main_dir, 'sum')
# sys.path.insert(0, cus)
# from . import custom_model1 
import sys
sys.path.append("C:/Users/Playdata/Desktop/web_project/custom_utils")
# from utils import load_model
from utils.load_model import model_file_load
from django.http import JsonResponse
import os
import time
def sum_page(request):
    
    # print("생성전")
    mymodel=model_file_load('C:/Users/Playdata/Desktop/web_project/custom_utils/summary_model.pt','digit82/kobart-summarization') # 파일 경로를 넣어야함 
    # print("생성후")
    if request.method == "POST":
        start =time.time()
        raw_text= request.POST.get('text', '')
        input_text=mymodel.predict(raw_text)
        end=time.time()
        dur=end-start
        print(dur,'초')
        # 여기서 input_text를 가공하거나 처리한 뒤 결과를 JSON으로 반환
        response_data = {'processed_text': input_text}
        return JsonResponse(response_data)
    return render(request,'sum/summarize.html')
