from django.urls import path
from.views import sum_page
urlpatterns = [
    path("", sum_page, name="sum-page"),
    
    
]