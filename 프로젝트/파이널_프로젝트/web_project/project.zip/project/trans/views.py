from django.shortcuts import render,redirect
from django.contrib import messages
import sys

sys.path.append("C:/Users/Playdata/Desktop/web_project/custom_utils")
# from utils import load_model
from utils.load_model import model_file_load
from django.http import JsonResponse
import os
import time
def trans_page(request):

    mymodel=model_file_load('C:/Users/Playdata/Desktop/web_project/custom_utils/trans_model.pt',"Helsinki-NLP/opus-mt-ko-en") # 파일 경로를 넣어야함 

    if request.method == "POST":
        start =time.time()
        raw_text= request.POST.get('text', '')

        input_text=mymodel.predict(raw_text)
        # 여기서 input_text를 가공하거나 처리한 뒤 결과를 JSON으로 반환
        response_data = {'processed_text': input_text}
        end=time.time()
        dur=end-start
        print(dur,'번역초')
        return JsonResponse(response_data)
    return render(request,'trans/translate.html')

