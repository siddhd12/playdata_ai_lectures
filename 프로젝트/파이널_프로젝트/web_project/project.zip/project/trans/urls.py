from django.urls import path
from.views import trans_page
urlpatterns = [
    path("", trans_page, name="trans-page"),
    
    
]