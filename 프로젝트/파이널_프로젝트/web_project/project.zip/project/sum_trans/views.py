from django.shortcuts import render,redirect
from django.contrib import messages
# from utils.load_model import model_load
from django.http import JsonResponse
import time
import sys
sys.path.append("C:/Users/Playdata/Desktop/web_project/custom_utils")
# from utils import load_model
from utils.load_model import model_file_load
def sum_trans_page(request):

    mymodel_sum=model_file_load('C:/Users/Playdata/Desktop/web_project/custom_utils/summary_model.pt','digit82/kobart-summarization') # 요약모델 파일 경로를 넣어야함
    mymodel_trans= model_file_load('C:/Users/Playdata/Desktop/web_project/custom_utils/trans_model.pt',"Helsinki-NLP/opus-mt-ko-en") # 요약모델 파일 경로를 넣어야함

    if request.method == "POST":
        start =time.time()
        raw_text= request.POST.get('text', '')

        input_text_sum=mymodel_sum.predict(raw_text)
        input_text_trans=mymodel_trans.predict(input_text_sum)

        # 여기서 input_text를 가공하거나 처리한 뒤 결과를 JSON으로 반환
        response_data = {'processed_text_sum': input_text_sum,
                        'processed_text_trans': input_text_trans}
        end=time.time()
        dur=end-start
        print(dur)
        return JsonResponse(response_data)
    return render(request,'sum_trans/sum_trans.html')

