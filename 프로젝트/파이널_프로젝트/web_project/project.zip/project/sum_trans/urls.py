from django.urls import path
from.views import sum_trans_page
urlpatterns = [
    path("", sum_trans_page, name="sum_trans-page"),
    
    
]