from django.apps import AppConfig


class SumTransConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "sum_trans"
